class FollowerModel {
    public userID: number;
    public vacationID: number;
}

export default FollowerModel