class CredentialsModel {
	public username: string;
    public password: string;
}

export default CredentialsModel;
