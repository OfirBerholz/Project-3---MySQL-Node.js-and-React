enum RoleModel {
    Admin = 1,
    User = 2
};

export default RoleModel;